import React from "react";
import { View, Text } from "react-native";

const Login = ({ navigation }) => {
  return (
    <View>
      <Text>This is Login page</Text>
    </View>
  );
};

export { Login };
